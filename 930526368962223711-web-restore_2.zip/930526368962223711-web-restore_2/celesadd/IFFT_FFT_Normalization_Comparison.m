% obj.tables.initialFieldCoefficients
% obj.tables.initialFieldCoefficients'
% obj.input.initialField.beamWidth
% l=1 3
% l=2 5
% l=3 7
% 
% sqrt(2*1+1)
% sqrt(2*2+1)
% sqrt(2*3+1)
% 
% -i.^[1 2 3]*sin(pi/2)
% 
% -i.^(1+[1 2 3])*(-i)*sin(pi/2)

% % -1.7292*exp(

% (-1.721+0.0791i)/-1.7292

% log(0.9953 - 0.0457i)/i

% exp(-i*0.04)

% 4*(2*pi/(550*10^-9))
E0=5;
nx=64*8;ny=64*8; %9*3 9*3 okay for 20x (Bdx4). 9*2 9*2 okay for 5x.
rx=2000;ry=rx;
SpaceX=4; 
XMax=rx*SpaceX; YMax=ry*SpaceX;
SpaceKx=4;
KxMax=(2/rx)*SpaceKx; KyMax=(2/ry)*SpaceKx;
Ext=16;
X=rx*Ext;
Y=ry*Ext;
if (X<2*XMax)
  warning('XMax is outside of the grid. Lower SpaceX by a factor of %s or increase Ext by that factor',num2str((2*XMax)/X))
end
if (Y<2*YMax)
  warning('YMax is outside of the grid. Lower SpaceX by a factor of %s or increase Ext by that factor',num2str((2*YMax)/Y))
end
if ((1/2)*(2*pi/(X/nx))<2*KxMax)
  warning('KxMax is outside of the grid. Lower (SpaceKx)(Ext) by a factor of %s or increase nx by that factor',num2str((2*KxMax)/((1/2)*(2*pi/(X/nx)))))
end
if ((1/2)*(2*pi/(Y/ny))<2*KyMax)
  warning('KyMax is outside of the grid. Lower (SpaceKx)(Ext) by a factor of %s or increase ny by that factor',num2str((2*KxMax)/((1/2)*(2*pi/(Y/ny)))))
end

%Make sure Kx and X are resolved
if (rx<3*(X/nx))
  warning('Beam profile is insufficiently resolved in x,y. Raise nx by a factor of %s or lower Ext by that factor',num2str(3*(X/nx)/rx))
end
if (ry<3*(Y/ny))
  warning('Beam profile is insufficiently resolved in x,y. Raise ny by a factor of %s or lower Ext by that factor',num2str(3*(Y/ny)/ry))
end
if ((2/rx)<3*(2*pi/(2*X)))
  warning('Insufficient resolution in Kx,Ky space. Raise Ext by a factor of %s',num2str(3*(2*pi/(2*X))/(2/rx)))
end
if ((2/ry)<3*(2*pi/(2*Y)))
  warning('Insufficient resolution in Kx,Ky space. Raise Ext by a factor of %s',num2str(3*(2*pi/(2*Y))/(2/ry)))
end


kx = 2*pi*[(0:nx),(-nx:-1)]'/(2*X);
ky = 2*pi*[(0:ny),(-ny:-1)]'/(2*Y);
x = (X/nx)*[(0:nx),(-nx:-1)]';
y = (Y/ny)*[(0:ny),(-ny:-1)]';
Arrayu0=zeros(nx+1,ny+1);Xvec=Arrayu0;Yvec=Arrayu0;

for px=1:(2*nx+1)
    for py=1:(2*ny+1)
        Arrayu0(px,py)=E0*exp(-(x(px)-2000)^2/(rx)^2-(y(py))^2/(ry)^2);
%        Arrayu0(px,py)=rand(1)*E0*exp(-(x(px))^2/(rx)^2-(y(py))^2/(ry)^2);
        Xvec(px,py)=x(px);
        Yvec(px,py)=y(px);
        KXvec(px,py)=-kx(px);
        KYvec(px,py)=-ky(px);
        rad(px,py)=sqrt((x(px))^2+(y(py))^2);
    end
end
FTMat=(2/pi)*nx^2*ifftn(Arrayu0')*(X^2/nx^2); %Properly normalized. This is the 1/sqrt(2pi)exp(-iwt) defn of FT. In Matlab this is IFFTN
figure()
mesh(kx,ky,imag(FTMat))
xlabel('kx (nm^{-1})')
ylabel('ky (nm^{-1})')
max(max(imag(FTMat)))



x=-x;y=-y;
for px=1:(2*nx+1)
    for py=1:(2*ny+1)
        Arrayu0(px,py)=E0*exp(-(x(px)-2000)^2/(rx)^2-(y(py))^2/(ry)^2);
%        Arrayu0(px,py)=rand(1)*E0*exp(-(x(px))^2/(rx)^2-(y(py))^2/(ry)^2);
        Xvec(px,py)=x(px);
        Yvec(px,py)=y(px);
        KXvec(px,py)=-kx(px);
        KYvec(px,py)=-ky(px);
        rad(px,py)=sqrt((x(px))^2+(y(py))^2);
    end
end
FTMat=(1/(2*pi))*fftn(Arrayu0')*(X^2/nx^2); %Properly normalized. This is the 1/sqrt(2pi)exp(-iwt) defn of FT. In Matlab this is IFFTN
%This is how I'm able to normalize everything. Matches mathematica
kx=-kx;ky=-ky; %Since I'm defining FTMat as Int(dx f(x) exp(ikx x)d) which maps exp(iKx x)-> kx=-Kx, see mathematica.
figure()
mesh(kx,ky,imag(FTMat))
xlabel('kx (nm^{-1})')
ylabel('ky (nm^{-1})')
max(max(imag(FTMat)))



% % figure()
% % mesh((X/nx)*(-nx:nx),(Y/ny)*(-ny:ny),fftshift(abs(Arrayu0).^2))
% % figure()
% % mesh(2*pi*(-nx:nx)/(2*X),2*pi*(-ny:ny)/(2*Y),fftshift(abs(fftn(Arrayu0)).^2/max(max(abs(fftn(Arrayu0)).^2))))


% max(max(abs(FTMat)))
% FTMat=2*pi*ifftn(Arrayu0')/(X^2/nx^2); %Properly normalized. This is the 1/sqrt(2pi)exp(-iwt) defn of FT. In Matlab this is IFFTN
% max(max(abs(FTMat)))
% % % FTMat=ifftn(Arrayu0')*X^2
% % max(max(abs(FTMat)))
% % % max(max(FTMat))
% % 
% % % max(max(abs(FTMat)))
% % %max(max(abs(ifftn(Arrayu0))))/(KxMax^2/nx^2)
% figure()
% max(max(abs(fftn(ifftn(Arrayu0')))))
% figure()
% max(max(abs(Arrayu0')))
% 
% FTMat=(1/(2*pi))*fftn(Arrayu0')*(X^2/nx^2)
% Arrayu0=2*pi*ifftn(FTMat')/(X^2/nx^2)
% 
% max(max(abs(Arrayu0)))