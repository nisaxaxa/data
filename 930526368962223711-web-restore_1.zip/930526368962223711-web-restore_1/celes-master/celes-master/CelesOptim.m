%% load mesh
x=-1000:2000/64:1000;
y=-1000:2000/64:1000;
for i=1:length(x)
    for j=1:length(y)
     Arrayu0(i,j)=exp(-(x(i)^2+y(j)^2)/(2*(1000/3)^2));
    end
end
Arrayu0=fft2(Arrayu0);
Arrayu0=Arrayu0/norm(Arrayu0);
%
ak=Arrayu0;
% ak=fft2(full(G_im));
% ak=zeros(size(ak));
% ak(1)=1;
% ak=ak/norm(ak);
% akf=ak;
% trb=norm(CELES_MAIN(ak,x,y))/norm(ak)
m=1;
dk=conj(CELES_MAIN(ak,x,y));
dk=conj(CELES_MAIN(flipud(fliplr(dk)),x,y));
dk=-2*flipud(fliplr(dk));
% dk=-2*flp(conj(CELES_MAIN(flp(conj(CELES_MAIN(ak,x,y))),x,y)));
p=2;
% while p>.001
for q=1:10
d=conj(CELES_MAIN(dk,x,y));
d=conj(CELES_MAIN(flipud(fliplr(d)),x,y));
d=flipud(fliplr(d));
% d=flp(conj(CELES_MAIN(flp(conj(CELES_MAIN(dk,x,y))),x,y)));
    if m==1
        rkp(m,:).rkp=dk;
    else
    end
mukp=norm(rkp(m,:).rkp)^2/norm(CELES_MAIN(dk,x,y))^2; 
% mukp=norm(rkp(m,:).rkp)^2/sum(conj(dk).*d,'all');
ak=ak+mukp*dk;
ak=ak/norm(ak);
rkp(m+1,:).rkp=rkp(m,:).rkp-mukp*d;
disp('p-value in jin paper')
p=norm(rkp(m+1,:).rkp)
bkp=norm(rkp(m+1,:).rkp)^2/norm(rkp(m,:).rkp)^2; %beta
dk=rkp(m+1,:).rkp+bkp*dk;
m=m+1;
end


imagesc(abs(ifft2(ak)))
tra=norm(CELES_MAIN(abs(ak),x,y))/norm(ak)
