%  Copyright (c) 2017, Amos Egel (KIT), Lorenzo Pattelli (LENS)
%                      Giacomo Mazzamuto (LENS)
%  All rights reserved.
%
%  Redistribution and use in source and binary forms, with or without
%  modification, are permitted provided that the following conditions are met:
%
%  * Redistributions of source code must retain the above copyright notice, this
%    list of conditions and the following disclaimer.
%
%  * Redistributions in binary form must reproduce the above copyright notice,
%    this list of conditions and the following disclaimer in the documentation
%    and/or other materials provided with the distribution.
%
%  * Neither the name of the copyright holder nor the names of its
%    contributors may be used to endorse or promote products derived from
%    this software without specific prior written permission.
%
%  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
%  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
%  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
%  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
%  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
%  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
%  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
%  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
%  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
%  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
%  POSSIBILITY OF SUCH DAMAGE.

%===============================================================================
%> @brief Expansion coefficients of a plane wave under normal incidence as the
%>        initial field in terms of regular spherical vector wave functions
%>        relative to the particles centers
%>
%> @param simulation (celes_simulation)
%>
%> @retval aI (device_array (CPU or GPU) of dimension NS x nmax, single
%>         precision)
%===============================================================================
function aI = initial_field_coefficients_planewave(simulation)
lmax = simulation.numerics.lmax;
E0 = simulation.input.initialField.amplitude;
k = simulation.input.k_medium;
relativeParticlePositions = simulation.input.particles.positionArray - simulation.input.initialField.focalPoint;
Arrayu0 = simulation.input.Arrayu0;
x = simulation.input.x;
y = simulation.input.y;

Arrayu0=circshift((fftshift(Arrayu0)),[1,1]);
nx=(length(x)-1)/2;ny=nx;
X=max(x);
Y=max(y);
kx = 2*pi*[(0:nx),(-nx:-1)]'/(2*X);
ky = 2*pi*[(0:ny),(-ny:-1)]'/(2*Y);
dkx=2*pi/(2*X);
dky=2*pi/(2*Y);
x = (X/nx)*[(0:nx),(-nx:-1)]';
y = (Y/ny)*[(0:ny),(-ny:-1)]';
% Arrayu0=zeros(nx+1,ny+1);
Xvec=zeros(2*nx+1,2*ny+1);Yvec=zeros(2*nx+1,2*ny+1);
KXvec=zeros(2*nx+1,2*ny+1);KYvec=zeros(2*nx+1,2*ny+1);

x=-x;y=-y;
for px=1:(2*nx+1)
    for py=1:(2*ny+1)
%         Arrayu0(px,py)=E0*exp(-(x(px)-2000)^2/(rx)^2-(y(py))^2/(ry)^2); %Insert the actual E(x,y). Ignore the x=-x, y=-x. It's just to use fft instead of ifft
%        Arrayu0(px,py)=rand(1)*E0*exp(-(x(px))^2/(rx)^2-(y(py))^2/(ry)^2);
%           Arrayu0(px,py)=E0*exp(-(x(px))^2/(rx)^2-(y(py))^2/(ry)^2); %Insert the actual E(x,y). Ignore the x=-x, y=-x. It's just to use fft instead of ifft
%          Arrayu0(px,py)=E0*1; %Insert the actual E(x,y). Ignore the x=-x, y=-x. It's just to use fft instead of ifft
%         Xvec(px,py)=x(px);
%         Yvec(px,py)=y(px);
        KXvec(px,py)=-kx(px);
        KYvec(px,py)=-ky(py);
%         rad(px,py)=sqrt((x(px))^2+(y(py))^2);
    end
end
% figure()
% mesh(x,y,abs(Arrayu0).^2)

FTMat=(1/(2*pi))*fftn(Arrayu0)*(X^2/nx^2); %Properly normalized. This is the 1/sqrt(2pi)exp(-iwt) defn of FT. In Matlab this is IFFTN
%This is how I'm able to normalize everything. Matches mathematica
kx=-kx;ky=-ky; %Since I'm defining FTMat as Int(dx f(x) exp(ikx x)d) which maps exp(iKx x)-> kx=-Kx, see mathematica.
% figure()
% mesh(kx,ky,abs(FTMat).^2)
% xlabel('kx (nm^{-1})')
% ylabel('ky (nm^{-1})')
% axis([-k k -k k])

% eikr = exp(1i*relativeParticlePositions*kvec);

% clear k beta cb sb kvec relativeParticlePositions % clean up some memory?
clear beta cb sb kvec % clean up some memory?

% compute initial field coefficients

% kvec=[   ]
% kvec=kvec;
% Propaxisvec=[0 0 1]
% Theta=
% Phi=

 
phiP=0;thetaP=0; kz=k; ky=0; kx=0;
aI = simulation.numerics.deviceArray(zeros(simulation.input.particles.number,simulation.numerics.nmax,'single'));
aIadd=aI;

for ikx=1:length(x)
%     disp(ikx)
    for iky=1:length(y)
        aI=0*aI;
        kx=KXvec(ikx,iky);
        ky=KYvec(ikx,iky);
        if sqrt(kx^2+ky^2)<k
%            if 1==1
        kz=sqrt(k^2-kx^2-ky^2);
%        kz=k;
        thetaP=acos(kz/k);
%        thetaP=acos(kz/sqrt(kz^2+kx^2+ky^2));
        phiP=atan(ky/kx);
        if isnan(phiP)
            phiP=0;
        end
        if isnan(thetaP)
            thetaP=0;
        end

%         if isnan(thetaP)
%             thetaP=0;
%         end
%         if isnan(phiP)
%             phiP=0
%         end
for m=-lmax:lmax
    for tau=1:2
        for l=max(1,abs(m)):lmax
            n=multi2single_index(1,tau,l,-m,lmax); %Note: I've switched the m value to create correspondence
            if tau==2 %i.e. plug in MY a_lm result (which corresponds Doicu's b_lm result)
                if abs(l)<abs(-m-1)
            aI(:,n) = (1/sqrt(2*pi))*4*pi*i^(l+1)*(-1)^(m+1)*(0*sqrt((l-m)*(l+m+1))+harmonicY(l,-m+1,thetaP,phiP)*sqrt((l+m)*(l-m+1)))/sqrt(2*l*(l+1)); %What Doucu's a_lm ought to be
                elseif abs(l)<abs(-m+1)
            aI(:,n) = (1/sqrt(2*pi))*4*pi*i^(l+1)*(-1)^(m+1)*(harmonicY(l,-m-1,thetaP,phiP)*sqrt((l-m)*(l+m+1))+0*sqrt((l+m)*(l-m+1)))/sqrt(2*l*(l+1)); %What Doucu's a_lm ought to be
                else 
            aI(:,n) = (1/sqrt(2*pi))*4*pi*i^(l+1)*(-1)^(m+1)*(harmonicY(l,-m-1,thetaP,phiP)*sqrt((l-m)*(l+m+1))+harmonicY(l,-m+1,thetaP,phiP)*sqrt((l+m)*(l-m+1)))/sqrt(2*l*(l+1)); %What Doucu's a_lm ought to be
                end
            aI(:,n)=-(aI(:,n)); %Coefficients get reversed between my coeff's and Douci's
%             aI(:,n)=conj(aI(:,n)); %Not needed in this version: It seemed that CELES has complex conjugate of Douci's coefficients, with x axis being 'TM' mode and y axis being 'TE' mode.
           else      %i.e. plug in MY b_lm result (which corresponds Doicu's a_lm result)
                if abs(l)<abs(-m-1)
                aI(:,n) = (1/sqrt(2*pi))*(4/k)*pi*i*i^(l+1)*(-i*kz*(-1)^(m+1)*0*sqrt((l-m)*(l+m+1))+i*kz*(-1)^(m+1)*harmonicY(l,-m+1,thetaP,phiP)*sqrt((l+m)*(l-m+1))-ky*(-1)^(m)*harmonicY(l,-m,thetaP,phiP)*m)/sqrt(2*l*(l+1)); %What Doucu's b_lm ought to be
                elseif abs(l)<abs(-m+1)
                aI(:,n) = (1/sqrt(2*pi))*(4/k)*pi*i*i^(l+1)*(-i*kz*(-1)^(m+1)*harmonicY(l,-m-1,thetaP,phiP)*sqrt((l-m)*(l+m+1))+i*kz*(-1)^(m+1)*0*sqrt((l+m)*(l-m+1))-ky*(-1)^(m)*harmonicY(l,-m,thetaP,phiP)*m)/sqrt(2*l*(l+1)); %What Doucu's b_lm ought to be
                else
                aI(:,n) = (1/sqrt(2*pi))*(4/k)*pi*i*i^(l+1)*(-i*kz*(-1)^(m+1)*harmonicY(l,-m-1,thetaP,phiP)*sqrt((l-m)*(l+m+1))+i*kz*(-1)^(m+1)*harmonicY(l,-m+1,thetaP,phiP)*sqrt((l+m)*(l-m+1))-ky*(-1)^(m)*harmonicY(l,-m,thetaP,phiP)*m)/sqrt(2*l*(l+1)); %What Doucu's b_lm ought to be
                end
                aI(:,n)=-(aI(:,n)); %Coefficients get reversed between my coeff's and Douci's
%             aI(:,n)=conj(aI(:,n)); %Not needed in this version: It seemed that CELES has complex conjugate of Douci's coefficients, with x axis being 'TM' mode and y axis being 'TE' mode.
            aI(:,n)=aI(:,n).*exp(1i*kx*relativeParticlePositions(:,1)+1i*ky*relativeParticlePositions(:,2)+1i*kz*relativeParticlePositions(:,3));

            end
    end
    end
end
% aI=aI*(FTMat(2*nx+2-ikx,2*nx+2-iky))*dkx*dky;
aI=aI*FTMat(ikx,iky)*dkx*dky;
aIadd=aIadd+aI;
% disp('size of aI is')
% disp(size(aI))
        end
    end
end
disp('HERE')
aI=aIadd/(2*pi); %For proper normalization.

